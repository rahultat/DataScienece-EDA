import { Button, CssBaseline, Grid, Typography, Box, AppBar, Toolbar } from '@mui/material';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { unSetUserToken } from '../../features/authSlice';
import { getToken, removeToken } from '../../services/LocalStorageService';
import { Link } from 'react-router-dom';
import { NavLink } from "react-router-dom";

import { useGetLoggedUserQuery } from '../../services/userAuthApi';
import { useEffect, useState } from 'react';
import { setUserInfo, unsetUserInfo } from '../../features/userSlice';
import { Navigation } from 'react-minimal-side-navigation';
import 'react-minimal-side-navigation/lib/ReactMinimalSideNavigation.css';


import React from "react";

import "react-minimal-side-navigation/lib/ReactMinimalSideNavigation.css";
import ViewUser from '../auth/ViewUser';

import { FaHome, FaUsers, FaCodepen, FaAvianex, FaBook,FaThumbsUp } from 'react-icons/fa';

import { ProSidebar, Menu, MenuItem, SubMenu, SidebarFooter } from 'react-pro-sidebar';

import 'react-pro-sidebar/dist/css/styles.css';
import '../dashboard.scss'







const ViewUserDash = () => {





  const handleLogout = () => {
    dispatch(unsetUserInfo({ name: "", email: "" }))
    dispatch(unSetUserToken({ access_token: null }))
    removeToken()
    navigate('/login')
  }
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const { access_token } = getToken()
  const { data, isSuccess } = useGetLoggedUserQuery(access_token)

  const [userData, setUserData] = useState({
    email: "",
    name: "",
    role: ""
  })

  // Store User Data in Local State
  useEffect(() => {
    if (data && isSuccess) {
      setUserData({
        email: data.email,
        name: data.name,
        role: data.role
      })
    }
  }, [data, isSuccess])

  // Store User Data in Redux Store
  useEffect(() => {
    if (data && isSuccess) {
      dispatch(setUserInfo({
        email: data.email,
        name: data.name
      }))
    }
  }, [data, isSuccess, dispatch])

  return <>
    <CssBaseline />
    {/* <Grid container>
      <Grid item sm={4} sx={{ backgroundColor: 'gray', p: 5, color: 'white' }}>
        <h1>Dashboard</h1>
        <Typography variant='h5'>Email: {userData.email}</Typography>
        <Typography variant='h6'>Name: {userData.name}</Typography>
        <Typography variant='h6'>Role: {userData.role}</Typography>
        <Button variant='contained' color='warning' size='large' onClick={handleLogout} sx={{ mt: 8 }}>Logout</Button>
      </Grid>
      <Grid item sm={8}>
        <ChangePassword />
      </Grid>
    </Grid> */}



    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static" color="secondary">
        <Toolbar>
          <Typography variant='h5' component="div" sx={{ flexGrow: 1 }}>Shipping Container System</Typography>
          <div style={{ display: "flex", justifyContent: "space-between", color: 'white', textTransform: 'none' }}>
            <Typography variant='h6'  >Welcome</Typography> 	&nbsp; 	&nbsp; 	&nbsp;
            <Typography variant='h6'  > {userData.name}   </Typography>  &nbsp; 	&nbsp; 	&nbsp;
            <Button variant='contained' color='warning' size='large' onClick={handleLogout} >Logout</Button>
          </div>
        </Toolbar>
      </AppBar>
    </Box>


    <Grid container>

      <Grid  >
        <ProSidebar  >
          <Menu iconShape="reactange">
            <MenuItem icon={<FaHome size={20} />}>Home <Link to="/dashboard" /></MenuItem>
            <SubMenu title="Users" icon={<FaUsers size={20} />}>
              <MenuItem>Add</MenuItem>
              <MenuItem>View/Update  <Link to="../viewuser" />  </MenuItem>
            </SubMenu>
            <SubMenu title="Containers" icon={<FaCodepen size={20} />}>
              <MenuItem>Add</MenuItem>
              <MenuItem>View/Update  <Link to="../viewuser" />  </MenuItem>
            </SubMenu>
            <SubMenu title="Trips" icon={<FaAvianex size={20} />}>
              <MenuItem>Add</MenuItem>
              <MenuItem>View/Update</MenuItem>
            </SubMenu>
            <MenuItem icon={<FaBook size={20} />}>Reports <Link to="#" /></MenuItem>
          </Menu>

          {/* <SidebarFooter>
   
  </SidebarFooter> */}
        </ProSidebar>
        </Grid>



      


        
<ViewUser />





</Grid>












</>;
};

export default ViewUserDash;
