// import React, { useState } from 'react';
// import './viewuser.css'

// const ViewUser = () => {
//     const [users, setUsers] = useState([
//         { id: 1, firstName: 'Frank Murphy', email: 'frank.murphy@test.com', role: 'Container Owner', gst_nummber : 'ANVT12345', bal : '₹ 100000.00'   },
//         { id: 2, firstName: 'Vic Reynolds', email: 'vic.reynolds@test.com', role: 'Referral User', gst_nummber : 'XTRS2345', bal : '₹ 200000.00' },
//         { id: 3, firstName: 'Gina Jabowski', email: 'gina.jabowski@test.com', role: 'Container Owner',   gst_nummber : 'XTRS2345', bal : '₹ 500000.00'},
//         { id: 4, firstName: 'Jessi Glaser', email: 'jessi.glaser@test.com', role: 'Container Owner',  gst_nummber : 'QWET22345', bal : '₹ 600000.00' },
//         { id: 5, firstName: 'Jay Bilzerian', email: 'jay.bilzerian@test.com', role: 'Referral User' ,  gst_nummber : '3123RS2345', bal : '₹ 700000.00'}
//     ]);

//     return (
//         <div className="container">
//             <h3 className="p-3 text-center">React - Display a list of items</h3>
//             <table className="table table-striped table-bordered">
//                 <thead>
//                     <tr>
//                         <th>Name</th>
//                         <th>Email</th>
//                         <th>Role</th>
//                         <th>GST Number</th>
//                         <th>Outstanding Balance</th>
//                     </tr>
//                 </thead>
//                 <tbody>
//                     {users && users.map(user =>
//                         <tr key={user.id}>
//                             <td>{user.firstName} {user.lastName}</td>
//                             <td>{user.email}</td>
//                             <td>{user.role}</td>
//                             <td>{user.gst_nummber}</td>
//                             <td>{user.bal}</td>
//                         </tr>
//                     )}
//                 </tbody>
//             </table>
//         </div>
//     );
// }

// export default ViewUser;



import * as React from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { FaTrashAlt,FaPencilAlt } from 'react-icons/fa';




const MatEdit = ({ index }) => {
    const handleEditClick = () => {
      // some action
    };
  
    return (
      
        <FaPencilAlt/>
       
    );
  };


  const MatDelete = ({ index }) => {
    const handleEditClick = () => {
      // some action
    };
  
    return (
      
        <FaTrashAlt/>
       
    );
  };

const columns = [
  { field: 'id', headerName: 'ID', width: 70 },
  { field: 'Name', headerName: 'Name', width: 160 },
  { field: 'email', headerName: 'Email', width: 220 },
  {
    field: 'role',
    headerName: 'Role',
    width: 140,
  },
  { field: 'gst_nummber', headerName: 'GST Number', width: 160 },
  { field: 'bal', headerName: 'Outstanding Balance', width: 160 },

  {
    field: "edit",
    headerName: "Edit",
    sortable: false,
    width: 80,
    disableClickEventBubbling: true,
    renderCell: (params) => {
      return (
        <div
          className="d-flex justify-content-between align-items-center"
          style={{ cursor: "pointer" }}
        >
          <MatEdit index={params.row.id} />
        </div>
      );
    }
  },

  {
    field: "delete",
    headerName: "Delete",
    sortable: false,
    width: 80,
    disableClickEventBubbling: true,
    renderCell: (params) => {
      return (
        <div
          className="d-flex justify-content-between align-items-center"
          style={{ cursor: "pointer" }}
        >
          <MatDelete index={params.row.id} />
        </div>
      );
    }
  }


];

const rows = [
    { id: 1, Name: 'Frank Murphy', email: 'frank.murphy@test.com', role: 'Container Owner', gst_nummber : 'ANVT12345', bal : '₹ 100000.00'  },
             { id: 2, Name: 'Vic Reynolds', email: 'vic.reynolds@test.com', role: 'Referral User', gst_nummber : 'XTRS2345', bal : '₹ 200000.00' },
             { id: 3, Name: 'Gina Jabowski', email: 'gina.jabowski@test.com', role: 'Container Owner',   gst_nummber : 'XTRS2345', bal : '₹ 500000.00'},
             { id: 4, Name: 'Jessi Glaser', email: 'jessi.glaser@test.com', role: 'Container Owner',  gst_nummber : 'QWET22345', bal : '₹ 600000.00' },
            { id: 5,  Name: 'Jay Bilzerian', email: 'jay.bilzerian@test.com', role: 'Referral User' ,  gst_nummber : '3123RS2345', bal : '₹ 700000.00'}
 
];

const ViewUser = () => {
  return (
    <div style={{ height: 400, width: '80%', margin:'30px', paddingTop: '30px', textAlign:'center'  }}>
      <DataGrid
        rows={rows}
        columns={columns}
        pageSize={5}
        rowsPerPageOptions={[5]}
        checkboxSelection
      />
    </div>
  );
}

export default ViewUser;








