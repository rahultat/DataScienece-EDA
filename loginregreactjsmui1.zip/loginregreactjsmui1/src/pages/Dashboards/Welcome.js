

import { FaThumbsUp } from 'react-icons/fa';
import "./welcomemessage.css";

const WelcomeMessage = () => {

    return <>
    <div className="welcomemessage">
      <h1> <FaThumbsUp/>Success</h1>
      <h2>You are now logged in Shipping Container System.</h2>

      <h2>Click the menu item on the left navigation tab to see their application view.</h2>
    
    </div>

    </>

}

export default WelcomeMessage;